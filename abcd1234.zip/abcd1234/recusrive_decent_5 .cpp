#include<iostream>
#include<stdio.h>
#include<string>

using namespace std;

string str;
int pos,i,n,l;

bool match(char ch)
{
		if(i==l)
			return true;
		if(ch==str[i])
				{	
					i++;
					return true;
				}
		else		
			return false;
}

bool APrime(int n)
{
	n=i;
	if(i==l)
		return true;
	if(match('c'))
		if(APrime(i));
			{
				pos=i;
				return true;
			}
	i=n;
	if(match('a'))
		if(match('d'))
			if(APrime(i))
				{
					pos=i;
					return true;
				}
	return false;
}


bool A(int n)
{
	i = n;
	if(match('b')) {
		if(match('d'))
			return (APrime(i));
	}
	i=n;
	if(match('f'))
		return (APrime(i));
	return false;
}


bool S()
{
	i=pos;
	if(A(i))
		return (match('a'));
	i=pos;
	return (match('b'));
}

int main()
{
	i = 0;
	pos = 0;
	cin>>str;
	l=str.length()-1;
	if(S())
		cout<<"Valid string ";
	else 
		cout<<"Not a valid string";
}




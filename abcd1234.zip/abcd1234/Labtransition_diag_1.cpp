/*  
 1. WAP in C to implement the combined transition diagram for 
 i) identifiers: BEGIN, END, IF, THEN, ELSE ii) integer constants and 
 iii) relational operators: <, <=, =, < >, >, >= that are commonly used in any high level language. 


*/
#include<iostream>
using namespace std;

int main()
{
	string s;
	cin>>s;
	int n = s.length();
	
	int i=0;
	
	if(s[i]>='0' && s[i]<='9')
	{
		i++;
		while(i<n)
		{
			if(s[i]>='0' && s[i]<='9')
				i++;
			else
				break;
		}
		
		if(i==n)
		{
			cout<<"Integer Constant"<<endl;
		}
		else
		{
			cout<<"Not a valid token"<<endl;
		}
	}
	else
	{
	switch(s[i])
	{
		case 'b':
		{
			i++;
			if(s[i]=='e')
			{
				i++;
				if(s[i]=='g')
				{
					i++;;
					if(s[i]=='i')
					{
						i++;
						if(s[i]=='n')
						{
							i++;
						}
					}
				}
			}
			
			if(i==n)
			{
				cout<<"Valid Keyword"<<endl;
				break;
			}
			else
			{
				cout<<"Not a valid token"<<endl;
				break;
			}
		}		
		case 'e':
		{
			i++;
			if(s[i]=='l')
			{
				i++;
				if(s[i]=='s')
				{
					i++;;
					if(s[i]=='e')
					{
						i++;
					}
				}
			}
			else if(s[i]=='n')
			{
				i++;
				if(s[i]=='d')
				{
					i++;
				}
			}
			
			if(i==n)
			{
				cout<<"Valid Keyword"<<endl;
				break;
			}
			else
			{
				cout<<"Not a valid token"<<endl;
				break;
			}
		}
		case 'i':
		{
			i++;
			if(s[i]=='f')
			{
				i++;
			}
			
			if(i==n)
			{
				cout<<"Valid Keyword"<<endl;
				break;
			}
			else
			{
				cout<<"Not a valid token"<<endl;
				break;
			}
		}
		case 't':
		{
			i++;
			if(s[i]=='h')
			{
				i++;
				if(s[i]=='e')
				{
					i++;
					if(s[i]=='n')
					{
						i++;
					}
				}
			}
			
			if(i==n)
			{
				cout<<"Valid Keyword"<<endl;
				break;
			}
			else
			{
				cout<<"Not a valid token"<<endl;
				break;
			}
		}
		case '<':
		{
			i++;
			if(i==n)
			{
				cout<<"Valid Relational Operator"<<endl;
				break;
			}
			else if(i!=n && (s[i]=='=' || s[i]=='>'))
			{
				cout<<"Valid Relational Operator"<<endl;
				break;
			}
			else
			{
			cout<<"Not a valid token"<<endl;
			break;
			}
		}
		case '=':
		{
			i++;
			if(i==n)
			{
				cout<<"Valid Relational Operator"<<endl;
				break;
			}
			else
			{
			cout<<"Not a valid token"<<endl;
			break;
			}
		}
		case '>':
		{
			i++;
			if(i==n)
			{
				cout<<"Valid Relational Operator"<<endl;
				break;
			}
			else if(s[i]=='=')
			{
				cout<<"Valid Relational Operator"<<endl;
				break;
			}
			else
			{
			cout<<"Not a valid token"<<endl;
			break;
			}
		}
		default:
		{
			cout<<"Not a valid token"<<endl;
			break;
		}
	}
	}
	
	return 0;
}
